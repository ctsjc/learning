package com.example.msv0001;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Msv0001Application {

	public static void main(String[] args) {
		SpringApplication.run(Msv0001Application.class, args);
	}

}
