package com.example.msv0001;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Msv0001ApplicationTests {

	@Test
	void contextLoads() {
	}

}
