package com.japp.parsers

import com.japp.beans.JRequest

import scala.util.matching.Regex.MatchIterator

class Jparser {
  def readCurl(curl: String): Unit = {
    //println(curl)
    // split the line
    // extract All -H parts
    // Starty -H<space><single-quote>STUFF<single-quote><space>
    val splittedCurl = curl.split("\n");
    // extract URL
    var url = urlExtractor(curl)
    var method = methodExtractor(curl)
    // extract the headers
    var headers: Map[String, String] = headerExtractor(curl)
    var rawDataa = extractRawData(curl);
    //println(jRequest)
    var jRequest = new JRequest(url, method, headers, rawDataa)
    jRequest.display
    // headers.foreach(println)

  }
  private def extractRawData(curl: String): String = {
    var rawData = "";
    // """(?<=(-H '))(.*)(?='\s+\\?$)""".r
    var urlPattern = """(?<=(--data-raw '))(.*)(?='\s\\)""".r
    var matcherr = urlPattern.findAllIn(curl)
    if (matcherr.nonEmpty)
      rawData = matcherr.next()
    rawData

  }
  private def methodExtractor(curl: String): String = {
    var rawMethod = "";
    // """(?<=(-H '))(.*)(?='\s+\\?$)""".r
    var urlPattern = """(?<=(-X '))(.*)(?='\s\\)""".r
    var matcherr = urlPattern.findAllIn(curl)
    if (matcherr.nonEmpty)
      rawMethod = matcherr.next()
    rawMethod
  }

  private def urlExtractor(curl: String): String = {
    var rawUrl:String = "";
    // """(?<=(-H '))(.*)(?='\s+\\?$)""".r
    var urlPattern = """(?<=(curl '))(.*)(?='\s+)""".r
    var matcherr = urlPattern.findAllIn(curl)
    if (matcherr.nonEmpty)
      rawUrl = matcherr.next()

    rawUrl
  }

  private def headerExtractor(curl: String): Map[String, String] = {
    var headerPattern = """(?mis)(-H ')(.*)'\s+\\?$""".r
    var headers: Array[String] = curl.split('\n').map(a => {
      var headers: MatchIterator = headerPattern.findAllIn(a);
      var ll = headers.map(a => a)
      ll
    }).flatMap(a => {
      a
    }).map(a => {
      // Extracting the middle part of the Header
      // (?<=(<String that We wanted to Search>))
      // ?<= Anything after this. Also called after Match
      // (?=(<String that We wanted to Search>))
      // ?= Anything Before this. Also called before Match

      var hp = """(?<=(-H '))(.*)(?='\s+\\?$)""".r
      val vv = hp.findAllIn(a)
      vv
    }).flatMap(a => {
      a
    })

    var map1 = headers.map(v => {
      var vv: Array[String] = v.split(":")
      (vv.apply(0), vv.apply(1))
    }).toMap

    map1
  }
}