package com.japp.beans

case class JRequest( host: String,
                     method:String,
                headers : Map[String,String],
                     rawDataa: String
                   ) {

  def display: Unit = {
   println("host : "+host+
     "\nmethod : "+method+
     "\nRawData : "+rawDataa+
    "\nheaders : "+ headers.map(v => {
      "\n\t"+v._1+"\t->\t"+v._2
    }))
  }
}
