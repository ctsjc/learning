package com.japp.operations

import org.apache.http.client.methods.HttpGet
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils
import org.apache.http.{HttpEntity, HttpResponse}

class JExecute {

  var httpclient = HttpClients.createDefault();
  var httpget: HttpGet = new HttpGet("https://httpbin.org/get");

  // Request parameters and other properties.

  var response:HttpResponse = httpclient.execute(httpget);
  var entity:HttpEntity = response.getEntity();

  if (entity != null) {
    var instream  = entity.getContent();
    try {
      val str = EntityUtils.toString(entity,"UTF-8")
      println(str)
    } finally {
      instream.close();
    }
  }
}
