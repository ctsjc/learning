import com.japp.parsers.Jparser
import org.apache.http.HttpResponse
import org.apache.http.{HttpEntity, HttpResponse, NameValuePair}
import org.apache.http.client.methods.{HttpGet, HttpPost}
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils


@main def hello: Unit =
  println("Hello world!")
  println(msg)
  println("Hello World Pradeep!!!")
  val jparser =new Jparser()

  val curl = """curl 'https://www.youtube.com/youtubei/v1/log_event?alt=json&key=AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8' \
  -H 'authority: www.youtube.com' \
  -H 'sec-ch-ua: "Chromium";v="92", " Not A;Brand";v="99", "Google Chrome";v="92"' \
  -H 'x-origin: https://www.youtube.com' \
  -H 'x-youtube-device: cbr=Chrome&cbrver=92.0.4515.107&ceng=WebKit&cengver=537.36&cos=X11&cplatform=DESKTOP' \
  -H 'x-youtube-page-label: youtube.desktop.web_20210721_00_RC00' \
  -H 'authorization: SAPISIDHASH 1627193674_1a0a2a85f95de5f689b1b10ba4a75f903d94b67f' \
  -H 'x-youtube-page-cl: 385942097' \
  -H 'x-youtube-utc-offset: -240' \
  -H 'x-goog-authuser: 0' \
  -H 'x-youtube-time-zone: America/New_York' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36' \
  -H 'content-type: application/json' \
  -H 'x-youtube-client-name: 1' \
  -H 'x-youtube-client-version: 2.20210721.00.00' \
  -H 'x-youtube-identity-token: QUFFLUhqa21RR0dIdXROeENxbDR5U3lETzA2QVFVUEpXUXw=' \
  -H 'x-goog-visitor-id: CgtWendCYmlzczVfRSi6rvOHBg%3D%3D' \
  -H 'x-youtube-ad-signals: dt=1627182906692&flash=0&frm&u_tz=-240&u_his=13&u_java&u_h=1080&u_w=1920&u_ah=1080&u_aw=1920&u_cd=24&u_nplug=3&u_nmime=4&bc=31&bih=585&biw=1675&brdim=60%2C0%2C60%2C0%2C1920%2C0%2C1860%2C1080%2C1691%2C585&vis=1&wgl=true&ca_type=image' \
  -H 'accept: */*' \
  -H 'origin: https://www.youtube.com' \
  -H 'x-client-data: CJC2yQEIo7bJAQipncoBCIv9ygEIjJ7LAQinoMsBCPDwywEIrPLLAQjd8ssBCPDyywEItPjLAQiW+csBCJ75ywEI8fnLAQj7+csBCK/6ywEIsfrLARi68ssBGJD1ywE=' \
  -H 'sec-fetch-site: same-origin' \
  -H 'sec-fetch-mode: cors' \
  -H 'sec-fetch-dest: empty' \
  -H 'referer: https://www.youtube.com/watch?v=wCTDv1X2Sgg&ab_channel=SurMovies' \
  -H 'accept-language: en-US,en;q=0.9' \
  -H 'cookie: VISITOR_INFO1_LIVE=VzwBbiss5_E; LOGIN_INFO=AFmmF2swRQIhAOH7rzdE4WzYwfXDn9vuZrmp0gU1ZB5WqQXLlM3OQFJwAiBgGlUl0iznzNiSxzk1xJghp-xyhwx2oPuKRhX-JqX4Mw:QUQ3MjNmeF9KVFBSemxMSmRjZXJOLVhzS1V5YVRnT3ItU0c3YkFiOWlMbFZRTGo4TnBiX2daM0NtM3JtRDBDVmV2WTdDYm1BNlF3dHlwY2I4QmRfbnN2V3R4TjdabGw4U0JBWmplTGQtNUZtM3puSHdTaUdGNlZvcEZ2U3FrUjlvNTFJem0tcDFOZ0hqWTFidkt6Qkd3Wmo0VjVFUndiTmp3; __Secure-1PSID=_wfKBIu5FtjGA5JSLLtI8s9BrLbNcnIkQrDiMWcM0_lVpOREh8hJ97z-g03zcLqRioZ-OQ.; HSID=AfDU340aiZNgldzeN; SSID=AEJ9E78vP-MNbBfdz; APISID=CWNRdDRBAARL90hA/ARLYVuRrdNz7k6ZaY; SAPISID=cb5cqL0WK0VSO9y4/AJDnoEWh81gOOuzWk; __Secure-1PAPISID=cb5cqL0WK0VSO9y4/AJDnoEWh81gOOuzWk; __Secure-3PAPISID=cb5cqL0WK0VSO9y4/AJDnoEWh81gOOuzWk; SID=AAjKBPWgtcFnlI0T-sflwpyuZSZWdl6RJicyckL5NwDBPw_0-a04o4-VgACUu5Of4GoN6Q.; __Secure-3PSID=AAjKBPWgtcFnlI0T-sflwpyuZSZWdl6RJicyckL5NwDBPw_0hlrIZ8D_qmfrRipl2cRSFQ.; PREF=tz=America.New_York&f4=4000000&f5=30000; YSC=YlKqkVY3PNo; SIDCC=AJi4QfEK7kNBvoagLrJoXo0Sn4pJtaqGcQbS4mUQEt1ixo27eAhS8dPF4mJdLrNYj8oLsnEpgZ0; __Secure-3PSIDCC=AJi4QfEuGhFZjJHQOvahzNzObJBgTg_fWW6w6zDbydQQPzFtiwClhb0Pcz2M65iLUeiHwaTD7g' \
  --data-raw '{"context":{"client":{"hl":"en","gl":"US","clientName":1,"clientVersion":"2.20210721.00.00","configInfo":{"appInstallData":"CLqu84cGEKyh_RIQ0cCtBRC7w60FEO-n_RIQ2L6tBRCR-PwS"},"userAgent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36","screenDensityFloat":"1.100000023841858","mainAppWebInfo":{"webDisplayMode":"WEB_DISPLAY_MODE_BROWSER"},"connectionType":"CONN_CELLULAR_4G","browserName":"Chrome","browserVersion":"92.0.4515.107","osName":"X11","platform":"DESKTOP"}},"events":[{"eventTimeMs":1627193660176,"foregroundHeartbeat":{"firstActivityMs":"-1","clientDocumentNonce":"4VX80wHOU8GStEYU","index":"119","lastEventDeltaMs":"-1","trigger":"FOREGROUND_HEARTBEAT_TRIGGER_ON_FOREGROUND"},"context":{"lastActivityMs":"65633"}},{"eventTimeMs":1627193664347,"visualElementGestured":{"csn":"MC45NDUzNDY3MjQwNzgzMjk4","ve":{"trackingParams":"CM8BEKQwGAAiEwj9t5qPxf3xAhUB3MEKHflYDGBA6f2A4oOqlJjWAQ=="},"gestureType":"INTERACTION_LOGGING_GESTURE_TYPE_HOVER","clientData":{"thumbnailHoveredData":{"isMovingThumbnail":true,"movingThumbnailLoadingDurationMs":0,"durationHoveredMs":196,"videoId":"1jBRUDxAPuk"}}},"context":{"lastActivityMs":"179"}}],"requestTimeMs":1627193674356,"serializedClientEventId":{"serializedEventId":"Otf8YPG-E46YhwbIzqvICw","clientCounter":"25927"}}' \
  --compressed"""

  jparser.readCurl(curl)
def msg = "I was compiled by Scala 3. :)"
