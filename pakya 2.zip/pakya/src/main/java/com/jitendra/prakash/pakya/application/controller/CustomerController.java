package com.jitendra.prakash.pakya.application.controller;

import com.jitendra.prakash.pakya.application.bean.CustomerInfo;
import com.jitendra.prakash.pakya.application.bean.CustomerNotification;
import com.jitendra.prakash.pakya.application.bean.CustomerPakyaRelation;
import com.jitendra.prakash.pakya.application.service.PakyaManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController()
public class CustomerController {

    @Autowired
    PakyaManager manager;
    /*It will accept the customer information */
    @PostMapping("request")
    String acceptCustomerInfo(@RequestBody CustomerInfo customerInfo){
        String response="";
        manager.accept(customerInfo);
        return response;
    }

    /*This will be called by ajax... */
    @GetMapping("123")
    Optional<CustomerPakyaRelation> notifyCustomer1234(CustomerInfo customerInfo){
        return manager.notifyCustomer(customerInfo);
    }


    @GetMapping("update")
    CustomerNotification updateCustomer(){
        return null;
    }

}
