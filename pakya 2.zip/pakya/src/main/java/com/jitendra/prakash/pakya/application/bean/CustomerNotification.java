package com.jitendra.prakash.pakya.application.bean;

import lombok.Data;

@Data
public class CustomerNotification {
    PakyaServiceProvider serviceProvider;
}
