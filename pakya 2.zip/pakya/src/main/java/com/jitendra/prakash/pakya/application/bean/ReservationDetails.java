package com.jitendra.prakash.pakya.application.bean;

import lombok.Data;

@Data
public class ReservationDetails {
    String status;
}
