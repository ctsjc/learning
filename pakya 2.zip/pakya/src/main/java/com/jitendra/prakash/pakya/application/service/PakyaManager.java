package com.jitendra.prakash.pakya.application.service;

import com.jitendra.prakash.pakya.application.bean.CustomerInfo;
import com.jitendra.prakash.pakya.application.bean.CustomerPakyaRelation;
import com.jitendra.prakash.pakya.application.bean.PakyaServiceProvider;
import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.Optional;
import java.util.Queue;

@Service
public class PakyaManager {
    Queue<CustomerInfo> unprocessedQueue = new LinkedList<CustomerInfo>();
    Queue<CustomerInfo> inProcessedQueue = new LinkedList<CustomerInfo>();
    Queue<CustomerPakyaRelation> assignProcessedQueue = new LinkedList<CustomerPakyaRelation>();

    public void accept(CustomerInfo customerInfo){
        // send the customer info to the available clients
        // We will introduce the queue/kafka in later phase. for time being send the information to the in memory data structure
        unprocessedQueue.add( customerInfo );
        System.out.println("accept :: "+unprocessedQueue);
    }

    public CustomerInfo readUnprocessedCustomerRequest(){
        System.out.println("read :: "+unprocessedQueue);
        CustomerInfo customerInfo = unprocessedQueue.poll();
        inProcessedQueue.add(customerInfo);
        return customerInfo;
    }

    public void assignRelationship(CustomerInfo customerInfo, PakyaServiceProvider pakya ){
        CustomerPakyaRelation customerPakyaRelation = new CustomerPakyaRelation();
        customerPakyaRelation.setCustomerInfo(customerInfo);
        customerPakyaRelation.setPakyaServiceProvider(pakya);
        assignProcessedQueue.add(customerPakyaRelation);
        inProcessedQueue.remove(customerInfo);
    }

    public Optional<CustomerPakyaRelation> notifyCustomer(CustomerInfo customerInfo) {
        // check in assignedProccessQueue
        Optional<CustomerPakyaRelation> customerPakyaRelation = assignProcessedQueue.stream().filter(queue -> queue.getCustomerInfo().getName().equalsIgnoreCase(customerInfo.getName())).findFirst();
        return customerPakyaRelation;
    }
}
