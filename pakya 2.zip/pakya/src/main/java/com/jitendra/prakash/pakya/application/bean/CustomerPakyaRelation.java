package com.jitendra.prakash.pakya.application.bean;

import lombok.Data;

@Data
public class CustomerPakyaRelation {
    CustomerInfo customerInfo;
    PakyaServiceProvider pakyaServiceProvider;
}
