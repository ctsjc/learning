package com.jitendra.prakash.pakya.application.bean;

import lombok.Data;

@Data
public class PakyaServiceProvider {
    String name;
    String location;
    String contactInfo;
}
