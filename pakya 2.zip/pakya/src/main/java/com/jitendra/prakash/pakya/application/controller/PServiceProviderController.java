package com.jitendra.prakash.pakya.application.controller;

import com.jitendra.prakash.pakya.application.bean.CustomerInfo;
import com.jitendra.prakash.pakya.application.bean.JServiceDetails;
import com.jitendra.prakash.pakya.application.bean.ReservationDetails;
import com.jitendra.prakash.pakya.application.service.PakyaManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController("service123")
public class PServiceProviderController {

    @Autowired
    PakyaManager manager;
    /*this one is tricky, We are going to send the information to the ServiceProvider
    * for time being just consider its the AJAX request*/

    @GetMapping
    CustomerInfo sendNotification(){
        CustomerInfo customerInfo=manager.readUnprocessedCustomerRequest();
        return customerInfo;
    }


    /*If Provider accepts the request, it will update the system by raising the reservation requst*/
    ReservationDetails getReservationUpdate(){
        ReservationDetails reservationDetails=null;
        return reservationDetails;
    }


    /* get update about service*/
    void getServiceDetails(JServiceDetails jServiceDetails){
        // update customer about the details
    }


}
