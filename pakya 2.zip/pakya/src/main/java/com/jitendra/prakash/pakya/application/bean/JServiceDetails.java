package com.jitendra.prakash.pakya.application.bean;

import lombok.Data;

@Data
public class JServiceDetails {
    String status;
}
